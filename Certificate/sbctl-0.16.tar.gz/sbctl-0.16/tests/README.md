Integration tests
=================

Follow https://github.com/anatol/vmtest/blob/master/docs/prepare_image.md
Expects `/usr/share/edk2-ovmf/x64/OVMF_CODE.secboot.fd`  
